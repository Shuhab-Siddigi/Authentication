# This is a maven project

### Run
1. make build
2. make server
3. make client
